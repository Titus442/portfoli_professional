import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.util.Scanner;
import java.time.LocalDateTime;

public class Main {
    public static void main(String[] args) {
        String fechaInicio = fecha();
        String nombreUsuario = usuario();
        boolean jugarDeNuevo;
        do {
            final int numeroPreguntas = cuantasPreguntas();
            int contadorBien = 0, contadorMal = 0, porcentaje;
            String categoria = categoriaPreguntas();
            String[] preguntas = preguntasRandomizadas(categoria);
            String[] respuestas;
            for (int i = 0; i < numeroPreguntas; i++) {
                String[] partes = preguntasSeparadas(preguntas[i]);
                menuPreguntas(partes);
                respuestas = respuestasUsuario();
                if (respuestas[0].equalsIgnoreCase(partes[4])) {
                    System.out.println("\nRespuesta correcta, muy bien.\n");
                    contadorBien++;
                } else {
                    System.out.println("\nRespuesta incorrecta.\n");
                    contadorMal++;
                }
            }
            System.out.println("¡Felicidades por acabar el Quizz!\n");
            porcentaje = porcentageAciertos(contadorBien, numeroPreguntas);
            System.out.println("Tu porcentage de aciertos es: " + porcentaje + "%" + "\n" + mensajeFinal(porcentaje)+"\n");
            jugarDeNuevo = volverAJugar();
            String fechaFinal = fecha();
            historial(nombreUsuario, fechaInicio, fechaFinal, contadorBien, contadorMal);
        } while (jugarDeNuevo);
    }


    private static String usuario() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Bienvenido al Quizz de consciencia para la adopcion");
        System.out.println("¿Como te llamas?");
        return sc.nextLine();
    }

    private static int cuantasPreguntas() {
        Scanner sc = new Scanner(System.in);
        int numero;
        while (true) {
            System.out.println("¿Cuantas preguntas quieres hacer?");
            numero = sc.nextInt();
            if (numero >= 5 && numero <= 20) {
                return numero;
            } else {
                System.out.println("Mínimo han de ser 5 y máximo 20");
            }
        }
    }

    private static String categoriaPreguntas() {
        Scanner sc = new Scanner(System.in);
        String categoria;
        while (true) {
            System.out.println("¿Quieres adoptar un perro o un gato?");
            categoria = sc.nextLine();
            if (categoria.equalsIgnoreCase("perro") || categoria.equalsIgnoreCase("gato"))
                return categoria;
            System.out.println("Debes escribir 'perro' o 'gato'");
        }
    }

    private static String[] preguntasRandomizadas(String categoriaPreguntas){
        String[] preguntas = new String[20];
        int contador = 0;
        try {
            BufferedReader br;
            if (categoriaPreguntas.equalsIgnoreCase("perro")) {
                br = new BufferedReader(new FileReader("src/resources/perro.txt"));
            } else {
                br = new BufferedReader(new FileReader("src/resources/gato.txt"));
            }
            String linea;
            while ((linea = br.readLine()) != null) {
                preguntas[contador] = linea;
                contador++;
            }
            br.close();
        } catch (Exception e) {
            System.out.println("ERROR EN LA LECTURA DEL FICHERO");
        }
        Random r = new Random();
        for (int i = contador - 1; i > 0; i--) {
            int j = r.nextInt(i + 1);
            String temp = preguntas[i];
            preguntas[i] = preguntas[j];
            preguntas[j] = temp;
        }
        return preguntas;
    }

    private static String[] preguntasSeparadas(String linea){
        String[] partes = linea.split(";");
        String[] resultado = new String[5];
        for (int i = 0; i < partes.length && i < 5; i++) {
            resultado[i] = partes[i].trim();
        }
        return resultado;
    }

    private static void menuPreguntas(String partes[]) {
        System.out.println("------------------------");
        System.out.println(partes[0]);
        System.out.println("A: " + partes[1]);
        System.out.println("B: " + partes[2]);
        System.out.println("C: " + partes[3]);
        System.out.println("------------------------");
    }

    private static String[] respuestasUsuario() {
        Scanner sc = new Scanner(System.in);
        String[] respuestas = new String[1];
        while (true){
            System.out.println("Escribe tu respuesta");
            String respuesta = sc.nextLine();
            if(respuesta.equalsIgnoreCase("A")||respuesta.equalsIgnoreCase("B")||respuesta.equalsIgnoreCase("C")){
                respuestas[0] = respuesta;
                return respuestas;
            }else {
                System.out.println("Debes escribir 'A' o 'B' o 'C'");
            }
        }
    }

    private static int porcentageAciertos(int aciertos, int total){

        return (int) ((aciertos * 100.0) / total);
    }

    private static String mensajeFinal(int porcentaje) {


        if (porcentaje == 100) {
            return "¡Perfecto! Lo has hecho increíble";
        } else if (porcentaje >= 67) {
            return "¡Muy bien!";
        } else if (porcentaje >= 34) {
            return "No está mal, pero tienes que mejorar.";
        } else {
            return "No estás preparad@ para adoptar.";
        }
    }

    private static String fecha() {
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        return LocalDateTime.now().format(formato);
    }

    private static boolean volverAJugar() {
        Scanner sc = new Scanner(System.in);
        System.out.println("¿Quieres volver a jugar? (S/N)");
        String respuesta = sc.nextLine().trim().toUpperCase();
        return (respuesta.equals("S") || respuesta.equals("SI"));
    }

    private static void historial(String user,String fechaInicio, String fechaFinal,int contadorBien,int contadorMal){
        String datos = user + ";" + fechaInicio + ";" + fechaFinal + ";" + contadorBien + ";" + contadorMal;
        Path path= Paths.get("src/resources/historial.txt");
        try{
            Files.writeString(path, datos + System.lineSeparator(), StandardOpenOption.APPEND);
        }catch(Exception e){
            System.out.println("ERROR EN EL HISTORIAL");
        }

    }
}