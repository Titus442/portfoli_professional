<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <xsl:template match="/fitxes">
    <html>
        <head>
            <link rel="stylesheet" type="text/css" href="Estil.css"/>
            <title>Fitxes de les mascotes</title>
        </head>
        <body>
        <xsl:apply-templates select="fitxa"/>    
        <header>
        <nav>
            <div class="menu">
                <a href="WebInici.html" class="activo">Amics Peluts</a>
                <a href="adopta.html">Adopta!</a>
                <a href="historiesExit.html">Històries d'èxit</a>
                
            </div>
        </nav>
        </header>
        </body>
    </html>
    </xsl:template>
    <xsl:template match="fitxa">
        <div class="carta">
            <xsl:attribute name="class">
                <xsl:text>carta </xsl:text>
                <xsl:choose>
                    <xsl:when test="animal/@sexe='Mascle'">mascle</xsl:when>
                    <xsl:when test="animal/@sexe='Femella'">femella</xsl:when>
                </xsl:choose>
            </xsl:attribute>
            <div class="fila">
                <div class="col-esquerra">
                    <xsl:apply-templates select="animal"/>
                    <xsl:apply-templates select="propietari"/>
                    <xsl:apply-templates select="vacunacio"/>
                    <xsl:apply-templates select="visites"/>
                </div>
                <div class="col-dreta">
                    <div class="imatge">
                        <img src="fotos/{animal/foto}" alt="{animal/nom}" />
                    </div>
                </div>
            </div>    
        </div>
    </xsl:template>

    <xsl:template match="animal">
        <div class="info animal">
            <h2>
                <xsl:value-of select="nom"/>
                (<xsl:if test="@sexe='Mascle'">&#9794;</xsl:if>
                <xsl:if test="@sexe='Femella'">&#9792;</xsl:if>)
            </h2>
            <xsl:value-of select="concat('Data naixement: ', dataNaixement)"/><br/>
            <xsl:value-of select="concat('Pes: ', pes)"/><br/>
            <xsl:value-of select="concat('Color: ', color)"/><br/>
            <xsl:value-of select="concat('Tipus de cabell: ', @tipusCabell)"/><br/>
            <xsl:if test="pedigree='true'">
                <xsl:value-of select="concat('pedigree: ', '&#9989;')"/><br/>
            </xsl:if>
        </div>
    </xsl:template>

    <xsl:template match="propietari">
        <div class="info propietari">
            <h2>Propietari</h2>
            <xsl:value-of select="concat('Nom: ', nomProp, ' ', cognom)"/><br/>
            <xsl:value-of select="concat('Adreça: ', adreca)"/><br/>
            <xsl:value-of select="concat('Email: ', email)"/><br/>
            <xsl:value-of select="concat('Telèfon: ', telefon)"/><br/>
        </div>
    </xsl:template>

    <xsl:template match="vacunacio">
        <div class="info vacunacio">
            <h2>Vacunació</h2>
            <xsl:for-each select="vacuna">
                <strong>Vacuna <xsl:value-of select="position()"/>:</strong>
                <xsl:value-of select="concat(' ', nomVacuna)"/><br/>
                <xsl:value-of select="concat('Laboratori: ', @laboratori)"/><br/>
                <xsl:value-of select="concat('Data administració: ', dataAdm)"/><br/>
                <xsl:value-of select="concat('Proper record: ', dataProx)"/><br/>
            <br/>
            </xsl:for-each>  
        </div>  
    </xsl:template>

    <xsl:template match="visites">
        <div class="info visites">
            <h2>Visites</h2>
            <xsl:for-each select="visita">
                <strong>Visita <xsl:value-of select="position()"/>:</strong>
                <xsl:value-of select="concat('Data: ', data)"/><br/>
                <xsl:value-of select="concat('Motiu: ', motiu)"/><br/>
                <xsl:value-of select="concat('Diagnòstic: ', diagnostic)"/><br/>
                <xsl:value-of select="concat('Tractament: ', tractament)"/><br/>
                <xsl:value-of select="concat('Alta: ', alta)"/><br/>
                <br/>
            </xsl:for-each>
        </div>
    </xsl:template>

</xsl:stylesheet>  